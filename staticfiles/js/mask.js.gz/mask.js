$(document).ready(function(){
    $('#id_cel_phone').mask('(00) 00000-0000');
    $('#id_cpf').mask('000.000.000-00');
    $('#id_cep').mask('00000-000');
});
